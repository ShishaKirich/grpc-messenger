"""
Упрощенный клиент с метаданными
"""
import threading
import time
import traceback
from typing import Optional, Callable


# Временные заглушки для прото-файлов
class RegisterRequest:
    def __init__(self, login="", password=""):
        self.login = login
        self.password = password


class LoginRequest:
    def __init__(self, login="", password=""):
        self.login = login
        self.password = password


class Message:
    def __init__(self, author="", text=""):
        self.author = author
        self.text = text


class Empty:
    pass


class RegisterResponse:
    def __init__(self, success=True, error=""):
        self.success = success
        self.error = error


class LoginResponse:
    def __init__(self, success=True, error="", token=""):
        self.success = success
        self.token = token
        self.error = error


class AuthStub:
    def Register(self, request):
        print(f"Регистрация: {request.login}")
        return RegisterResponse(success=True, error="")

    def Login(self, request):
        print(f"Авторизация: {request.login}")
        return LoginResponse(success=True, token="dummy_token", error="")


class MessagingStub:
    def __init__(self):
        self._message_listener = None
        self._username = None

    def MessageStream(self, empty, metadata=None):
        # Заглушка - возвращает пустой генератор
        # В реальной реализации здесь бы был gRPC стрим с метаданными
        return []

    def SendMessage(self, message, metadata=None):
        print(f"Отправка: {message.author}: {message.text}")

        # Здесь должна быть реальная отправка на сервер
        # Для тестирования просто логируем

        # В реальной реализации здесь бы передавались метаданные
        if metadata:
            print(f"Метаданные: {metadata}")


class ChatClient:
    def __init__(self, port=8000, host='127.0.0.1'):
        self._port = port
        self._host = host
        self._on_message_receive: Optional[Callable] = None
        self._username: Optional[str] = None
        self._token: Optional[str] = None
        self._listening_thread: Optional[threading.Thread] = None
        self._stop_listening = threading.Event()
        # Добавляем callback для уведомлений о сообщениях
        self._message_callback: Optional[Callable] = None
        self._lock = threading.RLock()

        # Для хранения последнего сообщения (чтобы избежать дублирования)
        self._last_sent_message = None
        self._last_sent_time = 0

        print(f"Создан клиент для {host}:{port}")

        # Создаем заглушки
        self._msgs_service = MessagingStub()
        self._auth_service = AuthStub()

    def set_username(self, username):
        """Установить имя пользователя для метаданных"""
        with self._lock:
            self._username = username
            # Устанавливаем имя пользователя и в сервисе сообщений
            if hasattr(self._msgs_service, '_username'):
                self._msgs_service._username = username

    def set_message_callback(self, callback):
        """Установить callback для уведомлений о новых сообщениях"""
        with self._lock:
            self._message_callback = callback

    def register(self, login, password):
        try:
            resp = self._auth_service.Register(RegisterRequest(login=login, password=password))
            return resp.success
        except Exception as e:
            print(f"Ошибка регистрации: {e}")
            traceback.print_exc()
            return False

    def auth(self, login, password):
        try:
            resp = self._auth_service.Login(LoginRequest(login=login, password=password))
            if resp.success:
                self._token = resp.token
                self.set_username(login)  # Устанавливаем имя пользователя после авторизации
                return resp.token
            return None
        except Exception as e:
            print(f"Ошибка авторизации: {e}")
            traceback.print_exc()
            return None

    def start_listen_message(self, message_received):
        """Запуск прослушивания сообщений"""
        with self._lock:
            if self._listening_thread and self._listening_thread.is_alive():
                print("⚠ Слушатель уже запущен")
                return

            self._on_message_receive = message_received
            self._stop_listening.clear()

            print(f"✓ Слушатель сообщений запущен для пользователя: {self._username}")

            # Запускаем простой поток для эмуляции получения сообщений
            # В реальном приложении здесь был бы gRPC стрим
            self._listening_thread = threading.Thread(
                target=self._simple_message_listener,
                daemon=True,
                name=f"MessageListener_{self._username}"
            )
            self._listening_thread.start()

    def _simple_message_listener(self):
        """Простой слушатель сообщений - только ожидание новых сообщений"""
        try:
            print(f"✓ Слушатель начал работу")

            # В реальном приложении здесь был бы бесконечный цикл
            # получения сообщений из gRPC стрима
            while not self._stop_listening.is_set():
                time.sleep(1)  # Просто ждем, не генерируем сообщения

        except Exception as e:
            print(f"✗ Ошибка в слушателе сообщений: {e}")
            traceback.print_exc()

    def send_message(self, username, text):
        """Отправка сообщения с метаданными"""
        try:
            message = Message(author=username, text=text)

            # Устанавливаем имя пользователя если еще не установлено
            if not self._username:
                self.set_username(username)

            # Проверяем дублирование (чтобы избежать двойной отправки)
            current_time = time.time()
            with self._lock:
                if (self._last_sent_message == (username, text) and
                    current_time - self._last_sent_time < 1.0):
                    print(f"⚠ Пропускаем возможное дублирование сообщения")
                    return True

                self._last_sent_message = (username, text)
                self._last_sent_time = current_time

            # Логируем отправку
            print(f"📤 Отправка сообщения: {username}: {text}")

            # Вызываем сервис отправки
            metadata = {'username': self._username} if self._username else None
            self._msgs_service.SendMessage(message, metadata)

            # НЕ эмулируем получение своего же сообщения!
            # В реальном приложении сообщение вернется с сервера

            print(f"✓ Сообщение отправлено: {username}: {text}")
            return True

        except Exception as e:
            print(f"✗ Ошибка отправки сообщения: {e}")
            traceback.print_exc()
            return False

    def close(self):
        """Закрытие клиента"""
        print("🔒 Закрытие клиента...")

        # Останавливаем слушатель
        self._stop_listening.set()

        # Ждем завершения потока с таймаутом
        if self._listening_thread and self._listening_thread.is_alive():
            self._listening_thread.join(timeout=1.0)
            if self._listening_thread.is_alive():
                print("⚠ Предупреждение: поток слушателя не завершился вовремя")

        # Очищаем callback
        with self._lock:
            self._message_callback = None
            self._on_message_receive = None
            self._last_sent_message = None

        print("✓ Клиент закрыт")