# migrate_db.py - Миграция базы данных
import sqlite3
import os


def migrate_database():
    """Миграция существующей базы данных"""

    db_path = 'chat_data.db'

    if not os.path.exists(db_path):
        print("База данных не существует, создание новой...")
        return

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        # 1. Создаем новую таблицу сообщений если её нет
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS messages_new (
                id INTEGER PRIMARY KEY,
                chat_id TEXT NOT NULL,
                sender TEXT NOT NULL,
                message TEXT NOT NULL,
                message_type TEXT DEFAULT 'normal',
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # 2. Переносим данные из старой таблицы если существует
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='local_messages'")
        if cursor.fetchone():
            print("Миграция данных из local_messages...")
            cursor.execute('''
                INSERT INTO messages_new (chat_id, sender, message, message_type, timestamp)
                SELECT chat_id, sender, message, 'normal', timestamp 
                FROM local_messages
            ''')

        # 3. Создаем таблицу друзей если её нет
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS friends_new (
                id INTEGER PRIMARY KEY,
                user1 TEXT NOT NULL,
                user2 TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                requested_by TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user1, user2)
            )
        ''')

        # 4. Переносим данные из старой таблицы друзей если существует
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='friends'")
        if cursor.fetchone():
            print("Миграция данных из friends...")
            cursor.execute('''
                INSERT INTO friends_new (user1, user2, status, requested_by, created_at)
                SELECT username, friend_login, 'accepted', username, CURRENT_TIMESTAMP
                FROM friends
            ''')

        # 5. Создаем таблицу черного списка
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS blacklist_new (
                id INTEGER PRIMARY KEY,
                user_login TEXT NOT NULL,
                blocked_user TEXT NOT NULL,
                blocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_login, blocked_user)
            )
        ''')

        conn.commit()
        print("Миграция успешно завершена!")

    except Exception as e:
        print(f"Ошибка миграции: {e}")
        conn.rollback()
    finally:
        conn.close()


if __name__ == '__main__':
    migrate_database()