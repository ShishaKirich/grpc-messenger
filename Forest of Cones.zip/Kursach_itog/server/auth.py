import grpc
import sqlite3
from hashlib import sha256
from proto.auth_pb2 import *
from proto.auth_pb2_grpc import AuthServicer


class AuthService(AuthServicer):
    def __init__(self, db):
        self.db = db
        self.cursor = self.db.cursor()

    def Register(self, request, context):
        try:
            # Проверяем, существует ли уже такой логин
            self.cursor.execute("SELECT login FROM users WHERE login = ?", (request.login,))
            existing_user = self.cursor.fetchone()

            if existing_user:
                return RegisterResponse(success=False, error="Логин уже занят, попробуйте другой")

            # Хеширование пароля
            hashed_password = sha256(request.password.encode()).hexdigest()
            self.cursor.execute("INSERT INTO users (login, password_hash) VALUES (?, ?)",
                                (request.login, hashed_password))
            self.db.commit()
            return RegisterResponse(success=True)
        except sqlite3.IntegrityError:
            return RegisterResponse(success=False, error="Логин уже занят, попробуйте другой")
        except Exception as e:
            print(f"Ошибка регистрации: {e}")
            return RegisterResponse(success=False, error=f"Ошибка сервера: {str(e)}")

    def Login(self, request, context):
        self.cursor.execute("SELECT password_hash FROM users WHERE login = ?", (request.login,))
        row = self.cursor.fetchone()
        if not row:
            return LoginResponse(success=False, error="Пользователь не найден")

        # Проверка пароля
        if row[0] == sha256(request.password.encode()).hexdigest():
            return LoginResponse(success=True, token="dummy_token")  # Упрощенный токен
        else:
            return LoginResponse(success=False, error="Неверный пароль")