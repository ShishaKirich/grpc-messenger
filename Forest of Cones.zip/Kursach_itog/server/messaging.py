import grpc
import time
from threading import Lock
from proto.messaging_pb2 import *
from proto.messaging_pb2_grpc import MessagingServicer


class MessagingService(MessagingServicer):
    def __init__(self):
        # История всех сообщений
        self.__history = []
        self.__history_lock = Lock()
        # Активные стримы для каждого клиента
        self.__active_streams = []
        self.__streams_lock = Lock()

    def MessageStream(self, request, context):
        """Стрим сообщений для конкретного клиента"""
        try:
            last_read = len(self.__history) - 1

            # Добавляем этот стрим в активные
            with self.__streams_lock:
                self.__active_streams.append(context)

            while context.is_active():
                # Отправляем новые сообщения
                while last_read < len(self.__history) - 1:
                    with self.__history_lock:
                        if last_read < len(self.__history) - 1:
                            last_read += 1
                            message = self.__history[last_read]
                            yield message

                time.sleep(0.05)  # Небольшая задержка для экономии CPU

        except Exception as e:
            print(f"Ошибка в стриме: {e}")
        finally:
            # Удаляем стрим из активных при отключении
            with self.__streams_lock:
                if context in self.__active_streams:
                    self.__active_streams.remove(context)

    def SendMessage(self, message, context):
        """Отправка сообщения всем клиентам"""
        print(f"{message.author}: {message.text}")

        with self.__history_lock:
            self.__history.append(message)

        return Empty()