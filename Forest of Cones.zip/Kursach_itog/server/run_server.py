import grpc
from concurrent import futures
import sqlite3
import socket
import sys
from proto.auth_pb2_grpc import add_AuthServicer_to_server
from proto.messaging_pb2_grpc import add_MessagingServicer_to_server

from auth import AuthService
from sync_messaging import MessagingService


def check_port_available(port):
    """Проверка доступности порта"""
    try:
        # Создаем сокет
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.settimeout(2)

        # Пробуем забиндить порт
        result = sock.bind(('0.0.0.0', port))
        sock.close()
        return True
    except (socket.error, OSError) as e:
        print(f"Порт {port} занят: {e}")
        return False


def init_database():
    """Инициализация базы данных с тестовыми пользователями"""
    conn = sqlite3.connect('users.db', check_same_thread=False)
    cursor = conn.cursor()

    # Создаем таблицу пользователей
    cursor.execute('''CREATE TABLE IF NOT EXISTS users
                     (id INTEGER PRIMARY KEY, login TEXT UNIQUE, password_hash TEXT)''')

    # Проверяем существование тестовых пользователей
    test_users = [
        ('Bob', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3'),  # 123
        ('Alice', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3'),  # 123
        ('Charlie', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3'),  # 123
    ]

    for login, password_hash in test_users:
        cursor.execute('SELECT login FROM users WHERE login = ?', (login,))
        if not cursor.fetchone():
            try:
                cursor.execute('INSERT INTO users (login, password_hash) VALUES (?, ?)',
                               (login, password_hash))
                print(f"✓ Создан тестовый пользователь: {login}")
            except sqlite3.IntegrityError:
                print(f"⚠ Пользователь {login} уже существует")

    conn.commit()
    conn.close()
    print("✓ База данных инициализирована")


def serve(port=8000):
    # Проверяем доступность порта
    if not check_port_available(port):
        print(f"\nОшибка: Порт {port} уже занят!")
        print("Возможные решения:")
        print("1. Закройте другие экземпляры сервера")
        print("2. Используйте другой порт: python run_server.py 8001")
        print("3. Найдите и завершите процесс, занимающий порт:")
        print(f"   Windows: netstat -ano | findstr :{port}")
        print(f"   Linux/Mac: lsof -i :{port}")
        return

    # Инициализируем базу данных
    init_database()

    # Подключение к SQLite
    conn = sqlite3.connect('users.db', check_same_thread=False)
    cursor = conn.cursor()

    try:
        server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
        add_AuthServicer_to_server(AuthService(conn), server)
        add_MessagingServicer_to_server(MessagingService(), server)

        # Используем правильный формат
        address = f'0.0.0.0:{port}'
        server.add_insecure_port(address)
        server.start()

        print("=" * 50)
        print(f"✓ Сервер успешно запущен")
        print(f"✓ Порт: {port}")
        print(f"✓ Адрес: localhost:{port}")
        print("=" * 50)
        print("\nДля подключения клиентов убедитесь, что:")
        print("1. Клиенты используют тот же порт")
        print("2. Файл client.py использует порт", port)
        print("\nДля остановки сервера нажмите Ctrl+C")
        print("=" * 50)

        server.wait_for_termination()

    except Exception as e:
        print(f"\n✗ Ошибка запуска сервера: {e}")
        print("\nВозможные причины:")
        print("1. Порт занят другим приложением")
        print("2. Недостаточно прав для использования порта")
        print("3. Проблемы с конфигурацией сети")

        if port < 1024:
            print("\n⚠ Примечание: Порты ниже 1024 требуют прав администратора")
            print("   Попробуйте порт выше 1024, например 8080")

    finally:
        if 'conn' in locals():
            conn.close()


if __name__ == '__main__':
    # Получаем порт из аргументов командной строки
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
            if port < 1 or port > 65535:
                print(f"Ошибка: Порт должен быть в диапазоне 1-65535")
                sys.exit(1)
            serve(port)
        except ValueError:
            print("Ошибка: Порт должен быть числом")
            print("Использование: python run_server.py [порт]")
            sys.exit(1)
    else:
        # Порт по умолчанию
        serve(8000)