# sync_messaging.py - Исправленный сервис обмена сообщений с системой друзей
import grpc
import time
from threading import Lock
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from proto.messaging_pb2 import *
from proto.messaging_pb2_grpc import MessagingServicer


class MessagingService(MessagingServicer):
    def __init__(self):
        # История сообщений для каждого чата/пользователя
        self.chat_history = defaultdict(list)
        self.history_lock = Lock()

        # Активные подключения для каждого пользователя
        self.active_connections = defaultdict(list)
        self.connections_lock = Lock()

        # Состояние друзей (для сервера)
        self.friend_requests = defaultdict(list)  # получатель -> [отправители]
        self.friends = defaultdict(set)  # пользователь -> {друзья}
        self.blocked_users = defaultdict(set)  # пользователь -> {заблокированные}
        self.relations_lock = Lock()

        # Кэш для сообщений о запросах в друзья
        self.friend_request_messages = defaultdict(list)

    def MessageStream(self, request, context):
        """Стрим сообщений для клиента"""
        try:
            # Получаем username из метаданных
            username = "unknown"
            metadata = dict(context.invocation_metadata())
            if 'username' in metadata:
                username = metadata['username']

            print(f"[СЕРВЕР] Начало стрима для пользователя: {username}")

            # Добавляем контекст в активные подключения
            with self.connections_lock:
                self.active_connections[username].append(context)

            # Индекс последнего прочитанного сообщения
            last_index = -1

            # Отправляем все ожидающие запросы в друзья сразу при подключении
            self.send_pending_friend_requests(username)

            # Также отправляем все системные сообщения
            self.send_system_messages(username)

            while context.is_active():
                # Получаем новые сообщения
                with self.history_lock:
                    # Получаем сообщения для пользователя
                    user_messages = self.get_user_messages(username)

                    if user_messages and len(user_messages) > last_index + 1:
                        for i in range(last_index + 1, len(user_messages)):
                            message = user_messages[i]
                            # Проверяем, не заблокирован ли отправитель
                            if not self.is_blocked(message.author, username):
                                print(f"[СЕРВЕР] Отправка сообщения {username}: {message.author}: {message.text}")
                                yield message
                                last_index = i

                time.sleep(0.05)  # Небольшая пауза

        except Exception as e:
            print(f"[СЕРВЕР] Ошибка в стриме для пользователя {username}: {e}")
        finally:
            # Удаляем контекст из активных подключений
            with self.connections_lock:
                if username in self.active_connections and context in self.active_connections[username]:
                    self.active_connections[username].remove(context)
                    print(f"[СЕРВЕР] Закрыт стрим для пользователя: {username}")

    def send_pending_friend_requests(self, username):
        """Отправка ожидающих запросов в друзья при подключении пользователя"""
        with self.relations_lock:
            if username in self.friend_requests and self.friend_requests[username]:
                for requester in self.friend_requests[username]:
                    # Отправляем уведомление о запросе
                    notification = Message()
                    notification.author = "Система"
                    notification.text = f"FRIEND_REQUEST:{requester}"
                    self.add_message(notification, [username])

                    # Отправляем информационное сообщение
                    info_msg = Message()
                    info_msg.author = "Система"
                    info_msg.text = f"Пользователь {requester} хочет добавить вас в друзья"
                    self.add_message(info_msg, [username])

                print(
                    f"[СЕРВЕР] Отправлено {len(self.friend_requests[username])} запросов в друзья пользователю {username}")

    def send_system_messages(self, username):
        """Отправка системных сообщений пользователю"""
        # Отправляем информацию о текущих друзьях
        with self.relations_lock:
            if username in self.friends:
                for friend in self.friends[username]:
                    info_msg = Message()
                    info_msg.author = "Система"
                    info_msg.text = f"FRIEND_INFO:{friend}:accepted"
                    self.add_message(info_msg, [username])

    def SendMessage(self, request, context):
        """Отправка сообщения"""
        print(f"[СЕРВЕР] Получено сообщение от {request.author}: {request.text}")

        # Получаем метаданные
        metadata = dict(context.invocation_metadata())
        sender_username = metadata.get('username', request.author)

        # Обновляем author если пришло из метаданных
        if sender_username != request.author:
            print(f"[СЕРВЕР] Исправляем отправителя с {request.author} на {sender_username}")
            request.author = sender_username

        # Добавляем временную метку с московским временем (UTC+3)
        moscow_time = self.get_moscow_time().strftime("%Y-%m-%d %H:%M:%S")
        setattr(request, 'timestamp', moscow_time)

        with self.history_lock:
            # Определяем тип сообщения и обрабатываем
            if request.text.startswith("FRIEND_REQUEST:"):
                # Запрос в друзья
                _, target_user = request.text.split(":", 1)
                print(f"[СЕРВЕР] {request.author} отправляет запрос в друзья {target_user}")

                # Проверяем, не пытается ли пользователь добавить себя
                if request.author == target_user:
                    print(f"[СЕРВЕР] Ошибка: пользователь пытается добавить себя в друзья")

                    error_msg = Message()
                    error_msg.author = "Система"
                    error_msg.text = "Нельзя добавить себя в друзья"
                    self.add_message(error_msg, [request.author])

                    return Empty()

                # Проверяем блокировки
                with self.relations_lock:
                    if request.author in self.blocked_users.get(target_user, set()):
                        print(f"[СЕРВЕР] Ошибка: {request.author} заблокирован пользователем {target_user}")

                        error_msg = Message()
                        error_msg.author = "Система"
                        error_msg.text = f"Вы заблокированы пользователем {target_user}"
                        self.add_message(error_msg, [request.author])

                        return Empty()

                # Сохраняем запрос
                with self.relations_lock:
                    if target_user not in self.blocked_users[request.author]:
                        if request.author not in self.friend_requests[target_user]:
                            self.friend_requests[target_user].append(request.author)
                            print(f"[СЕРВЕР] Запрос сохранен: {target_user} <- {request.author}")

                # Создаем системное сообщение для отправителя
                sender_msg = Message()
                sender_msg.author = "Система"
                sender_msg.text = f"FRIEND_REQUEST_SENT:{target_user}"
                self.add_message(sender_msg, [request.author])

                info_msg = Message()
                info_msg.author = "Система"
                info_msg.text = f"Запрос в друзья отправлен пользователю {target_user}. Ожидайте ответа."
                self.add_message(info_msg, [request.author])

                # Отправляем уведомление получателю (даже если он оффлайн, получит при следующем подключении)
                notification = Message()
                notification.author = "Система"
                notification.text = f"FRIEND_REQUEST:{request.author}"
                self.add_message(notification, [target_user])

                # Уведомление о новом запросе
                info_msg2 = Message()
                info_msg2.author = "Система"
                info_msg2.text = f"Пользователь {request.author} хочет добавить вас в друзья"
                self.add_message(info_msg2, [target_user])

            elif request.text.startswith("FRIEND_ACCEPTED:"):
                # Принятие запроса в друзья
                _, friend1, friend2 = request.text.split(":", 2)
                print(f"[СЕРВЕР] {friend1} принял запрос в друзья от {friend2}")

                with self.relations_lock:
                    # Добавляем в друзья
                    self.friends[friend1].add(friend2)
                    self.friends[friend2].add(friend1)

                    # Удаляем из pending запросов
                    if friend2 in self.friend_requests[friend1]:
                        self.friend_requests[friend1].remove(friend2)

                    print(f"[СЕРВЕР] Пользователи теперь друзья: {friend1} <-> {friend2}")

                # Отправляем уведомление обоим пользователям о подтверждении дружбы
                notification1 = Message()
                notification1.author = "Система"
                notification1.text = f"FRIEND_ACCEPTED:{friend1}:{friend2}"
                self.add_message(notification1, [friend1])

                notification2 = Message()
                notification2.author = "Система"
                notification2.text = f"FRIEND_ACCEPTED:{friend1}:{friend2}"
                self.add_message(notification2, [friend2])

                # Информационные сообщения
                info_msg1 = Message()
                info_msg1.author = "Система"
                info_msg1.text = f"Вы теперь друзья с {friend2}! Теперь вы можете обмениваться сообщениями."
                self.add_message(info_msg1, [friend1])

                info_msg2 = Message()
                info_msg2.author = "Система"
                info_msg2.text = f"Вы теперь друзья с {friend1}! Теперь вы можете обмениваться сообщениями."
                self.add_message(info_msg2, [friend2])

                # Отправляем информацию о новом друге
                friend_info1 = Message()
                friend_info1.author = "Система"
                friend_info1.text = f"FRIEND_INFO:{friend2}:accepted"
                self.add_message(friend_info1, [friend1])

                friend_info2 = Message()
                friend_info2.author = "Система"
                friend_info2.text = f"FRIEND_INFO:{friend1}:accepted"
                self.add_message(friend_info2, [friend2])

            elif request.text.startswith("FRIEND_REJECTED:"):
                # Отклонение запроса в друзья
                _, rejected_user, rejected_by = request.text.split(":", 2)
                print(f"[СЕРВЕР] {rejected_by} отклонил запрос от {rejected_user}")

                with self.relations_lock:
                    # Блокируем пользователя
                    self.blocked_users[rejected_by].add(rejected_user)

                    # Удаляем из pending запросов
                    if rejected_user in self.friend_requests[rejected_by]:
                        self.friend_requests[rejected_by].remove(rejected_user)

                    print(f"[СЕРВЕР] {rejected_user} заблокирован пользователем {rejected_by}")

                # Уведомление для отклоняющего
                notification1 = Message()
                notification1.author = "Система"
                notification1.text = f"FRIEND_REJECTED:{rejected_user}"
                self.add_message(notification1, [rejected_by])

                info_msg1 = Message()
                info_msg1.author = "Система"
                info_msg1.text = f"Вы отклонили запрос от {rejected_user}. Пользователь заблокирован."
                self.add_message(info_msg1, [rejected_by])

                # Уведомление для отклоненного
                notification2 = Message()
                notification2.author = "Система"
                notification2.text = f"FRIEND_REJECTED:{rejected_by}"
                self.add_message(notification2, [rejected_user])

                info_msg2 = Message()
                info_msg2.author = "Система"
                info_msg2.text = f"Пользователь {rejected_by} отклонил ваш запрос в друзья. Вы не можете отправлять ему сообщения."
                self.add_message(info_msg2, [rejected_user])

            elif request.text.startswith("UNBLOCK_USER:"):
                # Разблокировка пользователя
                _, target_user, unblocker = request.text.split(":", 2)
                print(f"[СЕРВЕР] {unblocker} разблокировал {target_user}")

                with self.relations_lock:
                    if target_user in self.blocked_users[unblocker]:
                        self.blocked_users[unblocker].remove(target_user)

                # Уведомление
                notification = Message()
                notification.author = "Система"
                notification.text = f"UNBLOCKED:{target_user}:{unblocker}"
                self.add_message(notification, [unblocker])

                info_msg = Message()
                info_msg.author = "Система"
                info_msg.text = f"Вы разблокировали пользователя {target_user}"
                self.add_message(info_msg, [unblocker])

            else:
                # Обычное личное сообщение
                print(f"[СЕРВЕР] Личное сообщение: {request.text}")
                self.process_personal_message(request)

        return Empty()

    def process_personal_message(self, message):
        """Обработка личного сообщения"""
        # Определяем получателя по формату "to:username сообщение"
        if "to:" in message.text.lower():
            try:
                parts = message.text.split(":", 1)
                if len(parts) > 1:
                    # Получаем первое слово после "to:"
                    recipient_part = parts[1].strip().split()[0]
                    recipient = recipient_part.strip()

                    # Оставляем только текст сообщения (без "to:username")
                    message_text = parts[1].replace(recipient, "", 1).strip()
                    if message_text:
                        message.text = message_text

                    print(f"[СЕРВЕР] Личное сообщение от {message.author} к {recipient}: {message.text}")

                    # Проверяем блокировки
                    with self.relations_lock:
                        if recipient in self.blocked_users.get(message.author, set()):
                            print(
                                f"[СЕРВЕР] {message.author} пытается написать заблокированному пользователю {recipient}")
                            return

                        # Проверяем, друзья ли
                        if recipient not in self.friends.get(message.author, set()):
                            print(f"[СЕРВЕР] {message.author} пытается написать недругу {recipient}")
                            return

                    # Отправляем сообщение получателю
                    self.add_message(message, [recipient, message.author])
                    return
            except Exception as e:
                print(f"[СЕРВЕР] Ошибка обработки личного сообщения: {e}")

        # Если не удалось определить получателя, отправляем всем
        print(f"[СЕРВЕР] Отправка сообщения всем")
        self.add_message(message, ["all"])

    def add_message(self, message, recipients):
        """Добавление сообщения для указанных получателей"""
        moscow_time = self.get_moscow_time()

        for recipient in recipients:
            if recipient not in self.chat_history:
                self.chat_history[recipient] = []

            # Добавляем сообщение с временной меткой
            timestamp_str = moscow_time.strftime("%Y-%m-%d %H:%M:%S")
            setattr(message, 'timestamp', timestamp_str)

            print(f"[СЕРВЕР] Сообщение для {recipient} в {timestamp_str}: {message.author}: {message.text}")

            self.chat_history[recipient].append(message)

            # Уведомляем активные подключения о новом сообщении
            self.notify_recipient(recipient)

    def notify_recipient(self, recipient):
        """Уведомление получателя о новом сообщении"""
        with self.connections_lock:
            if recipient in self.active_connections:
                connections = self.active_connections[recipient]
                print(f"[СЕРВЕР] Уведомление {recipient}: {len(connections)} активных соединений")

    def get_user_messages(self, username):
        """Получение сообщений для пользователя"""
        # Сообщения для всех
        all_messages = self.chat_history.get("all", [])

        # Персональные сообщения для пользователя
        personal_messages = self.chat_history.get(username, [])

        # Объединяем все сообщения
        all_user_messages = all_messages + personal_messages

        # Убираем дубликаты
        unique_messages = []
        seen_texts = set()
        for msg in all_user_messages:
            msg_id = f"{msg.author}:{msg.text}:{getattr(msg, 'timestamp', '')}"
            if msg_id not in seen_texts:
                seen_texts.add(msg_id)
                unique_messages.append(msg)

        print(f"[СЕРВЕР] Для {username} найдено {len(unique_messages)} сообщений")
        return unique_messages

    def get_moscow_time(self):
        """Получение текущего московского времени (UTC+3)"""
        utc_time = datetime.now(timezone.utc)
        moscow_offset = timedelta(hours=3)
        moscow_time = utc_time + moscow_offset
        return moscow_time

    def is_blocked(self, sender, recipient):
        """Проверка, заблокирован ли отправитель для получателя"""
        with self.relations_lock:
            is_blocked = sender in self.blocked_users.get(recipient, set())
            if is_blocked:
                print(f"[СЕРВЕР] {sender} заблокирован для {recipient}")
            return is_blocked

    def are_friends(self, user1, user2):
        """Проверка, дружат ли пользователи"""
        with self.relations_lock:
            are_friends = user2 in self.friends.get(user1, set())
            if are_friends:
                print(f"[СЕРВЕР] {user1} и {user2} друзья")
            return are_friends

    def has_pending_request(self, from_user, to_user):
        """Проверка, есть ли pending запрос"""
        with self.relations_lock:
            has_request = from_user in self.friend_requests.get(to_user, [])
            if has_request:
                print(f"[СЕРВЕР] {from_user} отправил запрос {to_user}")
            return has_request