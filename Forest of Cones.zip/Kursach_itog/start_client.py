"""
start_client.py - Исправленная версия запуска
"""

import sys
import os
import traceback

print("=" * 50)
print("Запуск мессенджера 'Лес из Шишек'")
print("=" * 50)

# Импортируем PySide6
try:
    from PySide6.QtWidgets import QApplication, QMessageBox
    from PySide6.QtCore import QObject, Signal, Slot
    from PySide6.QtGui import QFont
    print("✓ PySide6 доступен")
except ImportError as e:
    print(f"✗ PySide6 не установлен: {e}")
    input("Нажмите Enter для выхода...")
    sys.exit(1)


def import_module(module_name, file_path):
    """Динамически импортирует модуль из файла"""
    import importlib.util

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Файл не найден: {file_path}")

    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module  # Важно: добавляем в sys.modules
    spec.loader.exec_module(module)

    return module


class MainApp(QObject):
    """Главный контроллер приложения"""

    login_successful = Signal(str)

    def __init__(self):
        super().__init__()
        self.port = 8000
        self.host = '127.0.0.1'
        self.auth_window = None
        self.chat_window = None
        self.client = None
        self.ChatClient = None
        self.AuthWindow = None
        self.ChatWindow = None

    def load_modules(self):
        """Загрузка всех необходимых модулей"""
        print("\n[1/4] Поиск модулей...")

        # Добавляем текущую директорию в путь для импортов
        current_dir = os.path.dirname(os.path.abspath(__file__))
        sys.path.insert(0, current_dir)
        sys.path.insert(0, os.path.join(current_dir, 'pyqt_client'))

        # 1. Загружаем ChatClient
        print("\n[2/4] Загрузка ChatClient...")
        try:
            # Сначала пробуем обычный импорт
            try:
                from client import ChatClient
                self.ChatClient = ChatClient
                print("  ✓ ChatClient загружен через обычный импорт")
            except ImportError:
                # Пробуем найти файл
                client_paths = [
                    os.path.join('client', 'client.py'),
                    'client.py',
                    os.path.join(current_dir, 'client.py'),
                    os.path.join(current_dir, 'client', 'client.py')
                ]

                for path in client_paths:
                    if os.path.exists(path):
                        print(f"  Найден: {path}")
                        module = import_module('chatclient', path)
                        self.ChatClient = module.ChatClient
                        print(f"  ✓ ChatClient загружен из {path}")
                        break
                else:
                    raise ImportError("Не найден файл client.py")

        except Exception as e:
            print(f"  ✗ Ошибка загрузки ChatClient: {e}")
            traceback.print_exc()
            return False

        # 2. Загружаем AuthWindow
        print("\n[3/4] Загрузка AuthWindow...")
        try:
            # Пробуем обычный импорт
            try:
                from auth_window import AuthWindow
                self.AuthWindow = AuthWindow
                print("  ✓ AuthWindow загружен через обычный импорт")
            except ImportError:
                # Ищем файл
                auth_paths = [
                    os.path.join('pyqt_client', 'auth_window.py'),
                    'auth_window.py',
                    os.path.join(current_dir, 'pyqt_client', 'auth_window.py'),
                    os.path.join(current_dir, 'auth_window.py')
                ]

                for path in auth_paths:
                    if os.path.exists(path):
                        print(f"  Найден: {path}")
                        module = import_module('authwindow', path)
                        self.AuthWindow = module.AuthWindow
                        print(f"  ✓ AuthWindow загружен из {path}")
                        break
                else:
                    raise ImportError("Не найден файл auth_window.py")

        except Exception as e:
            print(f"  ✗ Ошибка загрузки AuthWindow: {e}")
            traceback.print_exc()
            return False

        # 3. Загружаем ChatWindow
        print("\n[4/4] Загрузка ChatWindow...")
        try:
            # Пробуем обычный импорт
            try:
                from chat_window import ChatWindow
                self.ChatWindow = ChatWindow
                print("  ✓ ChatWindow загружен через обычный импорт")
            except ImportError:
                # Ищем файл
                chat_paths = [
                    os.path.join('pyqt_client', 'chat_window.py'),
                    'chat_window.py',
                    os.path.join(current_dir, 'pyqt_client', 'chat_window.py'),
                    os.path.join(current_dir, 'chat_window.py')
                ]

                for path in chat_paths:
                    if os.path.exists(path):
                        print(f"  Найден: {path}")
                        module = import_module('chatwindow', path)
                        self.ChatWindow = module.ChatWindow
                        print(f"  ✓ ChatWindow загружен из {path}")
                        break
                else:
                    raise ImportError("Не найден файл chat_window.py")

        except Exception as e:
            print(f"  ✗ Ошибка загрузки ChatWindow: {e}")
            traceback.print_exc()
            return False

        print("\n✓ Все модули успешно загружены!")
        return True

    def start(self):
        """Запуск приложения"""
        print("\nЗапуск приложения...")

        # Определяем порт
        port_file = 'server_port.txt'
        if os.path.exists(port_file):
            try:
                with open(port_file, 'r') as f:
                    self.port = int(f.read().strip())
                    print(f"✓ Использую порт из файла: {self.port}")
            except:
                print(f"⚠ Использую порт по умолчанию: {self.port}")
        else:
            print(f"✓ Использую порт по умолчанию: {self.port}")

        # Создаем клиент
        try:
            self.client = self.ChatClient(port=self.port, host=self.host)
            print("✓ Клиент создан")
        except Exception as e:
            print(f"✗ Ошибка создания клиента: {e}")
            QMessageBox.critical(None, "Ошибка",
                               f"Не удалось создать клиент:\n{str(e)}")
            return False

        # Создаем окно авторизации
        self.auth_window = self.AuthWindow(self.client)

        # Подключаем сигнал успешного входа
        self.auth_window.login_successful.connect(self.open_chat_window)

        # Показываем окно авторизации
        self.auth_window.show()
        print("✓ Окно авторизации показано")

        return True

    @Slot(str)
    def open_chat_window(self, username):
        """Открыть окно чата после успешного входа"""
        print(f"✓ Успешный вход пользователя: {username}")

        try:
            # Закрываем окно авторизации
            if self.auth_window:
                self.auth_window.close()
                self.auth_window = None

            # Создаем окно чата
            self.chat_window = self.ChatWindow(self.client, username)
            self.chat_window.show()

            print("✓ Окно чата открыто")

        except Exception as e:
            print(f"✗ Ошибка открытия окна чата: {e}")
            traceback.print_exc()

            # Показываем сообщение об ошибке
            QMessageBox.critical(None, "Ошибка",
                               f"Не удалось открыть окно чата:\n{str(e)}")


def main():
    """Точка входа"""
    # Создаем приложение
    app = QApplication(sys.argv)
    app.setStyle('Fusion')

    # Устанавливаем шрифт
    font = QFont("Segoe UI", 10)
    app.setFont(font)

    # Создаем главный контроллер
    main_app = MainApp()

    # Загружаем модули
    if not main_app.load_modules():
        print("\n✗ Не удалось загрузить необходимые модули")
        print("\nПроверьте наличие файлов:")
        print("1. client.py или client/client.py")
        print("2. auth_window.py или pyqt_client/auth_window.py")
        print("3. chat_window.py или pyqt_client/chat_window.py")
        input("\nНажмите Enter для выхода...")
        return 1

    # Запускаем приложение
    if main_app.start():
        print("\n" + "=" * 50)
        print("✓ Приложение запущено успешно!")
        print("=" * 50)
        print("\nДоступные тестовые пользователи:")
        print("- Логин: Bob, Пароль: 123")
        print("- Логин: Alice, Пароль: 123")
        print("- Логин: Charlie, Пароль: 123")
        print("\nТакже можно создать нового пользователя")
        print("=" * 50)

        # Запускаем главный цикл
        sys.exit(app.exec())

    print("\n✗ Не удалось запустить приложение")
    input("Нажмите Enter для выхода...")
    return 1


if __name__ == '__main__':
    main()